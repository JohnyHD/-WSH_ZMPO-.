﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wypożyczalnia.Models;

namespace Wypożyczalnia.Controllers
{
    public class BookController : Controller
    {
        static IList<Book> bookList = new List<Book>
        {
            new Book() { BookId = 1, Autor = "Alicja Sinicka", Tytul = "Uwikłana", RokWydania = 2021, Nosnik = "Audiobook", Opis = "Czy potrafisz wyobrazić sobie sytuację, w której nie " +
                "możesz zaufać nawet najlepszym przyjaciołom? Kiedy wiesz, że każdy z nich może być… mordercą? Wydaje ci się, że wiesz o nich wszystko… aż do momentu, gdy znajdujesz zwłoki. " +
                "Później nic już nie jest pewne, a życie zamienia się w prawdziwy koszmar. Dla Mackenzie i jej sześciorga przyjaciół weekend w domku letniskowym miał być czasem totalnego " +
                "resetu od problemów codziennego życia. Szalona impreza zakończyła się jednak makabryczną niespodzianką: dwoje uczestników znaleziono martwych. W kałuży krwi. Mackenzie " +
                "wie jedno: morderca jest wśród nich, a wszyscy mieli własne powody, by zabić." },
            new Book() { BookId = 2, Autor ="Piotr Dmowski", Tytul = "W krainie piłkarskich bogów", RokWydania = 2020, Nosnik = "Forma papierowa" },
            new Book() { BookId = 3, Autor = "Dominik Rutkowski", Tytul = "Zadry", RokWydania = 2017, Nosnik = "Forma papierowa" },
            new Book() { BookId = 4, Autor = "Robert Plomin", Tytul = "Matryca", RokWydania = 2021, Nosnik = "PDF" }
        };

        public ActionResult Index()
        {
            return View(bookList.OrderBy(b => b.BookId).ToList());
        }

        public ActionResult Edit(int Id)
        {
            var std = bookList.Where(b => b.BookId == Id).FirstOrDefault();

            return View(std);
        }

        [HttpPost]
        public ActionResult Edit(Book std)
        {
            var book = bookList.Where(b => b.BookId == std.BookId).FirstOrDefault();
            bookList.Remove(book);
            bookList.Add(std);

            return RedirectToAction("Index");

        }

        public ActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Add(Book std)
        {
            std.BookId = bookList.Count() + 1;
            bookList.Add(std);

            return RedirectToAction("Index");
        }

        public ActionResult Details(int Id)
        {
            var std = bookList.Where(b => b.BookId == Id).FirstOrDefault();

            return View(std);
        }

        public ActionResult Delete(uint Id)
        {
            var std = bookList.Where(b => b.BookId == Id).FirstOrDefault();

            return View(std);
        }

        [HttpPost]
        public ActionResult Delete(int Id)
        {
            var std = bookList.Where(b => b.BookId == Id).FirstOrDefault();

            bookList.Remove(std);

            return RedirectToAction("Index");
        }
    }
}
