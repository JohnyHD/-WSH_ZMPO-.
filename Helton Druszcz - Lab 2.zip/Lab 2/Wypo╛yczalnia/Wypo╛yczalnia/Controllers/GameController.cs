﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wypożyczalnia.Models;

namespace Wypożyczalnia.Controllers
{
    public class GameController : Controller
    {
        static IList<Game> gameList = new List<Game>
        {
            new Game { GameId = 1, Tytul = "Granf Theft Auto: San Andreas", Studio = "Rockstar Games", RokProdukcji = 2004, Gatunek = "Akcja", Nosnik = "DVD", Opis = "Kolejna odsłona " +
                "jednej z najpopularniejszych i najbardziej kontrowersyjnych gier wszech czasów, w której gracz ma okazję wcielić się w drobnego rzezimieszka, a następnie tworząc własny, " +
                "kryminalny życiorys samemu stanąć na czele mafii."},
            new Game { GameId = 2, Tytul = "Back 4 Blood", Studio = "Turtle Rock Studio", RokProdukcji = 2021, Gatunek = "Akcja/Zombie", Nosnik = "Wersja cyfrowa", Opis = ""},
            new Game { GameId = 3, Tytul = "The Sims 4", Studio = "EA Maxis", RokProdukcji = 2014, Gatunek = "Symulacja", Nosnik = "Wersja cyfrowa", Opis = ""},
            new Game { GameId = 4, Tytul = "Gothic II: Noc Kruka", Studio = "Piranha Bytes", RokProdukcji = 2003, Gatunek = "RPG", Nosnik = "DVD", Opis = ""}
        };

        public ActionResult Index()
        {
            return View(gameList.OrderBy(g => g.GameId).ToList());
        }

        public ActionResult Edit(int id)
        {
            var std = gameList.Where(f => f.GameId == id).FirstOrDefault();

            return View(std);
        }

        [HttpPost]
        public ActionResult Edit(Game std)
        {
            var film = gameList.Where(f => f.GameId == std.GameId).FirstOrDefault();
            gameList.Remove(film);
            gameList.Add(std);

            return RedirectToAction("Index");
        }
        public ActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Add(Game std)
        {
            std.GameId = gameList.Count() + 1;
            gameList.Add(std);

            return RedirectToAction("Index");
        }

        public ActionResult Details(int id)
        {
            var std = gameList.Where(f => f.GameId == id).FirstOrDefault();
            return View(std);
        }

        public ActionResult Delete(uint id)
        {
            var std = gameList.Where(f => f.GameId == id).FirstOrDefault();
            return View(std);
        }

        [HttpPost]
        public ActionResult Delete(int id)
        {
            var std = gameList.Where(b => b.GameId == id).FirstOrDefault();

            gameList.Remove(std);

            return RedirectToAction("Index");
        }
    }
}

    
