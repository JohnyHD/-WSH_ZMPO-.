﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wypożyczalnia.Models;

namespace Wypożyczalnia.Controllers
{
    public class FilmController : Controller
    {
        static IList<Film> filmList = new List<Film>
        {
            new Film {FilmId = 1, Tytul = "The Matrix", Rezyser = "Lilly Wachowski / Lana Wachowski", RokProdukcji = 1999, Gatunek = "Sci-Fi" , Nosnik = "DVD", Opis = ""},
            new Film {FilmId = 2, Tytul = "Pamiętnik", Rezyser = "Nick Cassavetes", RokProdukcji = 2004, Gatunek = "Melodramat", Nosnik = "DVD", Opis = ""},
            new Film {FilmId = 3, Tytul = "RED", Rezyser = "Robert Schwentke", RokProdukcji = 2010, Gatunek = "Akcja/Komedia", Nosnik = "VOD", Opis = ""},
            new Film {FilmId = 4, Tytul = "Dziewczyny z Dubaju", Rezyser = "Maria Sadowska", RokProdukcji = 2021, Gatunek ="Dramat/Sensacyjny", Nosnik = "VOD", Opis = "Młoda ambitna dziewczyna " +
                "od lat marzy o wielkim świecie. Gdy tylko nadarza się okazja, bez wahania wskakuje w jego tryby, stając się ekskluzywną damą do towarzystwa. Wkrótce to ona na zaproszenie " +
                "arabskich szejków zaczyna werbować polskie miss, celebrytki, gwiazdy ekranu i modelki."},
        };

        public ActionResult Index()
        {
            return View(filmList.OrderBy(f => f.FilmId).ToList());
        }

        public ActionResult Edit(int id)
        {
            var std = filmList.Where(f => f.FilmId == id).FirstOrDefault();

            return View(std);
        }

        [HttpPost]
        public ActionResult Edit(Film std)
        {
            var film = filmList.Where(f => f.FilmId == std.FilmId).FirstOrDefault();
            filmList.Remove(film);
            filmList.Add(std);

            return RedirectToAction("Index");
        }

        public ActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Add(Film std)
        {
            std.FilmId = filmList.Count() + 1;
            filmList.Add(std);

            return RedirectToAction("Index");
        }

        public ActionResult Details(int id)
        {
            var std = filmList.Where(f => f.FilmId == id).FirstOrDefault();
            return View(std);
        }

        public ActionResult Delete(uint id)
        {
            var std = filmList.Where(f => f.FilmId == id).FirstOrDefault();
            return View(std);
        }

        [HttpPost]
        public ActionResult Delete(int id)
        {
            var std = filmList.Where(b => b.FilmId == id).FirstOrDefault();

            filmList.Remove(std);

            return RedirectToAction("Index");
        }
    }
}
