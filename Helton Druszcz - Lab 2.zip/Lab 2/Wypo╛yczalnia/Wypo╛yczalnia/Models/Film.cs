﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Wypożyczalnia.Models
{
    public class Film
    {
        [Display(Name = "ID")]
        public int FilmId { get; set; }

        [Display(Name = "Tytuł")]
        [Required]
        public string Tytul { get; set; }

        [Display(Name = "Reżyser")]
        [Required]
        public string Rezyser { get; set; }

        [Display(Name = "Rok produkcji")]
        [Range(1900, 2021)]
        public int RokProdukcji { get; set; }

        public string Gatunek { get; set; }

        [Display(Name = "Nośnik")]
        public string Nosnik { get; set; }

        public string Opis { get; set; }
    }
}
