﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Wypożyczalnia.Models
{
    public class Book
    {
        [Display(Name = "ID")]
        public int BookId { get; set; }

        public string Autor { get; set; }

        [Display(Name = "Tytuł")]
        public string Tytul { get; set; }

        [Display(Name = "Rok wydania")]
        public int RokWydania { get; set; }

        [Display(Name = "Nośnik")]
        public string Nosnik { get; set; }

        public string Opis { get; set; }
    }
}
