﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Wypożyczalnia.Models
{
    public class Game
    {
        [Display(Name = "ID")]
        public int GameId { get; set; }

        [Display(Name = "Tytuł")]
        public string Tytul { get; set; }

        public string Studio { get; set; }

        [Display(Name = "Rok produkcji")]
        public int RokProdukcji { get; set; }

        public string Gatunek { get; set; }

        [Display(Name = "Nośnik")]
        public string Nosnik { get; set; }

        public string Opis { get; set; }
    }
}
