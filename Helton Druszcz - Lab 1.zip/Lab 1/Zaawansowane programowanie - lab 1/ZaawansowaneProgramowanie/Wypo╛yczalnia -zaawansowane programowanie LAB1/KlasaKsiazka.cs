﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wypożyczalnia__zaawansowane_programowanie_LAB1
{
    class KlasaKsiazka
	{

		public int[] id = new int[1000];
		public string[] autor = new string[1000];
		public string[] tytul = new string[1000];
		public string[] nosnik = new string[1000];
		public uint[] czawypozycznia = new uint[1000];

		public void wyswietlksiazki(int identyfiaktor)
		{
			string tekst = "";
			tekst = "\nID: " + id[identyfiaktor] + "\nAutor: " + autor[identyfiaktor] + "\nTytuł: " + tytul[identyfiaktor] + "\nNośnik przechowywania: " + nosnik[identyfiaktor];
			Console.WriteLine(tekst);
		}
	}
}
