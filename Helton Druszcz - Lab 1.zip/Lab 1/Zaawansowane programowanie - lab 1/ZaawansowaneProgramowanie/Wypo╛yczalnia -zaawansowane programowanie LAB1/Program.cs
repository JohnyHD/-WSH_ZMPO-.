﻿using System;
using System.Threading;

namespace Wypożyczalnia__zaawansowane_programowanie_LAB1
{
    class Program
    {
        static void Main(string[] args)
        {
            //deklaracja klas
            KlasaKsiazka ksiazka = new KlasaKsiazka();
            KlasaFilm film = new KlasaFilm();
            KlasaGra gra = new KlasaGra();

            //zmienne do menu
            int wyborglowny = 0;
            int wybordodawania = 0;
            int wyborpodgladu = 0;
            int powrotmenugl = 0;

            //zmienne do książek
            int idksiazki = 0;
            int usunksiazke = 0;

            //zmienne do filmów
            int idfilmu = 0;
            int usunfilm = 0;

            //zmienne do gier
            int idgry = 0;
            int usungre = 0;

        start:
            Console.Clear();
            Console.WriteLine("*****Baza danych wypozyczalni*****\n");
            Console.WriteLine("Menu: \n1. Podglad elemntów \n2. Dodaj element \n3. Koniec");
            string wybglowny = Console.ReadLine();
            int.TryParse(wybglowny, out wyborglowny);

            switch(wyborglowny)
            {
                case 1:
                    {

                    podglad:
                        Console.Clear();
                        Console.WriteLine("*****Podgląd elemntów*****");
                        Console.WriteLine("1. Podgląd książek \n2. Podgląd filmów \n3. Podgląd gier \n4. Powrót");
                        string wybpodglad = Console.ReadLine();
                        int.TryParse(wybpodglad, out wyborpodgladu);

                        //książka
                        if(wyborpodgladu == 1)
                        {
                            wybksiazka:
                            Console.Clear();
                            Console.WriteLine("*****Podgląd książek*****");
                            for (int i = 1; i <= 100; i++)
                            {
                                if(ksiazka.id[i] > 0)
                                {
                                    ksiazka.wyswietlksiazki(i);
                                }
                            }

                            Console.WriteLine("\n1.Usuń książkę 2. Powrót do menu głównego");
                            string powdomenu = Console.ReadLine();
                            int.TryParse(powdomenu, out powrotmenugl);

                            if(powrotmenugl == 1)
                            {
                                Console.WriteLine("\n\nPodaj numer ID ksiązki do usunięcia");
                                string deletebook = Console.ReadLine();
                                int.TryParse(deletebook, out usunksiazke);

                                ksiazka.id[usunksiazke] = 0;
                                ksiazka.autor[usunksiazke] = "";
                                ksiazka.tytul[usunksiazke] = "";
                                ksiazka.nosnik[usunksiazke] = "";
                                ksiazka.czawypozycznia[usunksiazke] = 0;

                                Console.WriteLine("\n\n Usuwanie zakończone");

                                Thread.Sleep(2000);

                                goto wybksiazka;
                            }
                            else if(powrotmenugl == 2)
                            {
                                goto podglad;
                            }
                            else
                            {
                                Console.WriteLine("Wpiano zły znak!!!");
                                goto wybksiazka;
                            }
                        }
                        //film
                        else if(wyborpodgladu == 2)
                        {
                            wybfilm:
                            Console.Clear();
                            Console.WriteLine("*****Podgląd filmów*****");
                            for (int i = 1; i <= 100; i++)
                            {
                                if (film.id[i] > 0)
                                {
                                    film.wyswietlfilmy(i);
                                }
                            }

                            Console.WriteLine("1. Usuń film 2. Powrót do menu głównego");
                            string powdomenu = Console.ReadLine();
                            int.TryParse(powdomenu, out powrotmenugl);

                            if(powrotmenugl == 1)
                            {
                                Console.WriteLine("\n\nPodaj numer ID filmu do usunięcia");
                                string deletefilm = Console.ReadLine();
                                int.TryParse(deletefilm, out usunfilm);

                                film.id[usunfilm] = 0;
                                film.rezyser[usunfilm] = "";
                                film.tytul[usunfilm] = "";
                                film.rokprodukcji[usunfilm] = 0;
                                film.nosnik[usunfilm] = "";

                                Console.WriteLine("\n\n Usuwanie zakończone");

                                Thread.Sleep(2000);

                                goto wybfilm;
                            }
                            else if (powrotmenugl == 2)
                            {
                                goto podglad;
                            }
                            else
                            {
                                Console.WriteLine("Wpiano zły znak!!!");
                                goto wybfilm;
                            }
                        }
                        //gra
                        else if(wyborpodgladu == 3)
                        {
                        wybgra:
                            Console.Clear();
                            Console.WriteLine("*****Podgląd gier*****");
                            for (int i = 1; i <= 100; i++)
                            {
                                if (gra.id[i] > 0)
                                {
                                    gra.wyswietlgry(i);
                                }
                            }

                            Console.WriteLine("1. Usuń grę 2. Powrót do menu głównego");
                            string powdomenu = Console.ReadLine();
                            int.TryParse(powdomenu, out powrotmenugl);

                            if(powrotmenugl == 1)
                            {
                                Console.WriteLine("\n\nPodaj numer ID filmu do usunięcia");
                                string deletegame = Console.ReadLine();
                                int.TryParse(deletegame, out usungre);

                                gra.id[usungre] = 0;
                                gra.studio[usungre] = "";
                                gra.tytul[usungre] = "";
                                gra.rokprodukcji[usungre] = 0;
                                gra.nosnik[usungre] = "";

                                Console.WriteLine("\n\n Usuwanie zakończone");

                                Thread.Sleep(2000);

                                goto wybgra;
                            }
                            else if (powrotmenugl == 2)
                            {
                                goto podglad;
                            }
                            else
                            {
                                Console.WriteLine("Wpiano zły znak!!!");
                                goto wybgra;
                            }
                        }
                        else if(wyborpodgladu == 4)
                        {
                            goto start;
                        }
                        else
                        {
                            Console.WriteLine("Wpiano zły znak!!!");
                            goto podglad;
                        }

                        //break;
                    }

                case 2:
                    {
                    dodawanie:
                        Console.Clear();
                        Console.WriteLine("*****Dodawanie elemntu*****\n");
                        Console.WriteLine("1. Dodaj książke \n2. Dodaj film \n3. Dodaj gre \n4. Powrót");
                        string wybdodawania = Console.ReadLine();
                        int.TryParse(wybdodawania, out wybordodawania);

                        //ksiazka
                        if (wybordodawania == 1)
                        {
                            idksiazki++;
                            ksiazka.id[idksiazki] = idksiazki;

                            uint czaswypozyczenia = 0;

                            Console.Clear();
                            Console.WriteLine("*****Dodawanie książki*****\n");

                            Console.WriteLine("\nPodaj autora");
                            string autor = Console.ReadLine();
                            ksiazka.autor[idksiazki] = autor;

                            Console.WriteLine("\nPodaj tytuł");
                            string tytul = Console.ReadLine();
                            ksiazka.tytul[idksiazki] = tytul;

                            Console.WriteLine("\nPodaj nosnik, na którym znajduje się książka");
                            string nosnik = Console.ReadLine();
                            ksiazka.nosnik[idksiazki] = nosnik;

                            Console.WriteLine("\nPodaj czas, który minął od wypożyczenia");
                            string czaswyp = Console.ReadLine();
                            uint.TryParse(czaswyp, out czaswypozyczenia);
                            ksiazka.czawypozycznia[idksiazki] = czaswypozyczenia;

                            Console.WriteLine("\nDodawanie zakończone");

                            Thread.Sleep(2000);

                            goto start;

                        }

                        //film
                        else if(wybordodawania == 2)
                        {
                            idfilmu++;
                            film.id[idfilmu] = idfilmu;

                            uint rokprodukcji = 0;

                            Console.Clear();
                            Console.WriteLine("*****Dodawanie filmu*****\n");

                            Console.WriteLine("\nPodaj tytuł");
                            string tytul = Console.ReadLine();
                            film.tytul[idfilmu] = tytul;

                            Console.WriteLine("\nPodaj reżysera");
                            string rezyser = Console.ReadLine();
                            film.rezyser[idfilmu] = rezyser;

                            Console.WriteLine("\nPodaj rok produkcji");
                            string rokprod = Console.ReadLine();
                            uint.TryParse(rokprod, out rokprodukcji);
                            film.rokprodukcji[idfilmu] = rokprodukcji;

                            Console.WriteLine("\nPodaj nosnik, na którym znajduje się film");
                            string nosnik = Console.ReadLine();
                            film.nosnik[idfilmu] = nosnik;

                            Console.WriteLine("\nDodawanie zakończone");

                            Thread.Sleep(2000);

                            goto start;
                        }
                        //gry
                        else if(wybordodawania == 3)
                        {
                            idgry++;
                            gra.id[idgry] = idgry;

                            uint rokprodukcji = 0;

                            Console.Clear();
                            Console.WriteLine("*****Dodawanie gry*****");

                            Console.WriteLine("\nPodaj tytuł");
                            string tytul = Console.ReadLine();
                            gra.tytul[idgry] = tytul;

                            Console.WriteLine("\nPodaj studio");
                            string studio = Console.ReadLine();
                            gra.studio[idgry] = studio;

                            Console.WriteLine("\nPodaj rok produkcji");
                            string rokprod = Console.ReadLine();
                            uint.TryParse(rokprod, out rokprodukcji);
                            gra.rokprodukcji[idgry] = rokprodukcji;

                            Console.WriteLine("\nPodaj nosnik, na którym znajduje się film");
                            string nosnik = Console.ReadLine();
                            gra.nosnik[idgry] = nosnik;

                            Console.WriteLine("\nDodawanie zakończone");

                            Thread.Sleep(2000);

                            goto start;
                        }
                        else if(wybordodawania == 4)
                        {
                            goto start;
                        }
                        else
                        {
                            Console.WriteLine("Wpiano zły znak!!!");
                            goto dodawanie;
                        }
                        //break;
                    }
            }
        }
    }
}
