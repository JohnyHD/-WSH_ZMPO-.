﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wypożyczalnia__zaawansowane_programowanie_LAB1
{
    class KlasaFilm
    {
		public int[] id = new int[1000];
		public string[] tytul = new string[1000];
		public string[] rezyser = new string[1000];
		public uint[] rokprodukcji = new uint[1000];
		public string[] nosnik = new string[1000];

		public void wyswietlfilmy(int identyfiaktor)
		{
			string tekst = "";
			tekst = "\nID: " + id[identyfiaktor] + "\nReżyser: " + rezyser[identyfiaktor] + "\nTytuł: " + tytul[identyfiaktor] + "\nRok produkcji" + rokprodukcji[identyfiaktor] + "\nNośnik przechowywania: " + nosnik[identyfiaktor];
			Console.WriteLine(tekst);
		}
	}
}
